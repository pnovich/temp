﻿namespace KM.WebApp.Domain;

public class Class1
{

}
