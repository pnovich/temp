using System;

namespace KM.WebApp.Domain.DTOs
{
    public class EntryCreateDto
    {
        public Guid UserId { get; set; } // Існуючий користувач
        public bool IsActive { get; set; }
        public string Notes { get; set; }
    }
}