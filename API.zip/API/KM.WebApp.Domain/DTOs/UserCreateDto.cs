using System;

namespace KM.WebApp.Domain.DTOs
{
    public class UserCreateDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressCountry { get; set; }
        public string AddressRegion { get; set; }
        public string AddressState { get; set; }
        public string AddressCity { get; set; }
        public string AddressStreet { get; set; }
        public string AddressStreet2 { get; set; }
        public string AddressCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Notes { get; set; }
    }
}