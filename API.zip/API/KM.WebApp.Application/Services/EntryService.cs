using System;
using System.Collections.Generic;
using System.Linq;
using KM.WebApp.Application.Persistence;
using KM.WebApp.Domain.DTOs;
using KM.WebApp.Domain.Entities;
using KM.WebApp.Application.Services.Interfaces;

namespace KM.WebApp.Application.Services
{
    public class EntryService : IEntryService
    {
        private readonly AppDbContext _context;

        public EntryService(AppDbContext context)
        {
            _context = context;
        }

        public Entry CreateEntry(EntryCreateDto dto)
        {
            var entry = new Entry
            {
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                UserId = dto.UserId,
                IsActive = dto.IsActive,
                Notes = dto.Notes
            };

            _context.Entries.Add(entry);
            _context.SaveChanges();

            return entry;
        }

        public IEnumerable<Entry> GetAllEntries()
        {
            return _context.Entries.ToList();
        }
    }
}