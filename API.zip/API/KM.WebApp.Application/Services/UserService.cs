using System;
using System.Collections.Generic;
using System.Linq;
using KM.WebApp.Application.Persistence;
using KM.WebApp.Domain.DTOs;
using KM.WebApp.Domain.Entities;
using KM.WebApp.Application.Services.Interfaces;

namespace KM.WebApp.Application.Services
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        public User CreateUser(UserCreateDto dto)
        {
            var user = new User
            {
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                PhoneNumber = dto.PhoneNumber,
                AddressCity = dto.AddressCity,
                AddressRegion = dto.AddressRegion,
                AddressCode = dto.AddressCode,
                AddressState = dto.AddressState,
                AddressCountry = dto.AddressCountry,
                AddressStreet = dto.AddressStreet,
                AddressStreet2 = dto.AddressStreet2,
                Notes = dto.Notes
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return user;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }
    }
}