using System.Collections.Generic;
using KM.WebApp.Domain.DTOs;
using KM.WebApp.Domain.Entities;

namespace KM.WebApp.Application.Services.Interfaces
{
    public interface IEntryService
    {
        Entry CreateEntry(EntryCreateDto dto);
        IEnumerable<Entry> GetAllEntries();
    }
}