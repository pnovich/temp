﻿namespace KM.WebApp.Application;

public class Class1
{

}
