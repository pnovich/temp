using KM.WebApp.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace KM.WebApp.Application.Persistence;

public class AppDbContext : DbContext
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Entry> Entries => Set<Entry>();

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
}