using System.Collections.Generic;
using KM.WebApp.Application.Services.Interfaces;
using KM.WebApp.Domain.DTOs;
using KM.WebApp.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace KM.WebApp.API.Controllers
{
    [ApiController]
    [Route("users")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] UserCreateDto user)
        {
            var created = _userService.CreateUser(user);
            return CreatedAtAction(nameof(CreateUser), new { id = created.Id }, created);
        }

        [HttpGet]
        public ActionResult<IEnumerable<User>> GetAllUsers()
        {
            var users = _userService.GetAllUsers();
            return Ok(users);
        }
    }
}
