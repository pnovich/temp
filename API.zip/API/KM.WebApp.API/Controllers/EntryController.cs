using System.Collections.Generic;
using KM.WebApp.Application.Services.Interfaces;
using KM.WebApp.Domain.DTOs;
using KM.WebApp.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace KM.WebApp.API.Controllers
{
    [ApiController]
    [Route("entries")]
    public class EntryController : ControllerBase
    {
        private readonly IEntryService _entryService;

        public EntryController(IEntryService entryService)
        {
            _entryService = entryService;
        }

        [HttpPost]
        public IActionResult CreateEntry([FromBody] EntryCreateDto entry)
        {
            var created = _entryService.CreateEntry(entry);
            return CreatedAtAction(nameof(CreateEntry), new { id = created.Id }, created);
        }

        [HttpGet]
        public ActionResult<IEnumerable<Entry>> GetAllEntries()
        {
            var entries = _entryService.GetAllEntries();
            return Ok(entries);
        }
    }
}